<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="flex justify-center items-center flex-col h-[70vh]">
<h1 class="text-5xl text-center">Het bericht is verzonden!</h1>
<h2 class="text-center mt-5">We zullen er zo snel mogelijk op reageren.</h2>
<a href="/" class="mt-10 flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-[#5b9e8c] hover:bg-opacity-70 sm:px-8"> Ga terug </a>
</main>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tijdreis\Tijdreis\resources\views/contactsend.blade.php ENDPATH**/ ?>