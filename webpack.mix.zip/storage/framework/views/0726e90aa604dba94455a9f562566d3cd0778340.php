<!-- This file is used to store sidebar items, starting with Backpack\Base 0.9.0 -->
<li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('dashboard')); ?>"><i class='nav-icon lar la-chart-bar'></i> Statistieken</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('theme')); ?>'><i class='nav-icon las la-atlas'></i> Thema's</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('tour')); ?>'><i class='nav-icon las la-map-marked'></i> Tours</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('reservation')); ?>'><i class='nav-icon las la-clipboard-list'></i> Reserveringen</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('participant')); ?>'><i class='nav-icon las la-users'></i> Deelnemers</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('print')); ?>'><i class='nav-icon las la-print'></i> Printlijst</a></li><?php /**PATH C:\xampp\htdocs\Tijdreis\Tijdreis\resources\views/vendor/backpack/base/inc/sidebar_content.blade.php ENDPATH**/ ?>