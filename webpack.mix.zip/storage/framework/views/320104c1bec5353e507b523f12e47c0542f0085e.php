
<?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        // if the namespace is given, use that, no questions asked, otherwise
        // load it from the first view_namespace that holds that field
        if (isset($field['view_namespace'])) {
            $fieldPaths = [$field['view_namespace'].'.'.$field['type']];
        } else {
            $fieldPaths = array_map(function($item) use ($field) {
                return $item.'.'.$field['type'];
            }, config('backpack.crud.view_namespaces.fields'));
        }
    ?>

    <?php echo $__env->first($fieldPaths, ['field' => $field], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\xampp\htdocs\Tijdreis\Tijdreis\vendor\backpack\crud\src\resources\views\crud/inc/show_fields.blade.php ENDPATH**/ ?>